<?php
// Where will you get the forms' results?
define("CONTACT_FORM", 'yourname@yourdomain.com');
?>